﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ElectricalCircuitSimulator1
{
    public class Resistor
    {
        private bool isDragging;
        private Point startPoint;
        UIElement dragobject = null;
        Point offset;
        
		// Initialises the rectangle so it can be used
        public Rectangle Rectangle { get; }

		// Sets values for rectangle and creates icon
        public Resistor(double width, double height, Brush fill)
        {
            Rectangle = new Rectangle
            {
                Width = width,
                Height = height,
                Fill = fill

            };

            // Sets position of rectangle on canvas

            Canvas.SetLeft(Rectangle, 10);
            Canvas.SetTop(Rectangle, 10);

			// Adds events for the mouse to the rectangle
			Rectangle.MouseLeftButtonDown += Rectangle_MouseLeftButtonDown;
			Rectangle.MouseMove += Rectangle_MouseMove;
			Rectangle.MouseLeftButtonUp += Rectangle_MouseLeftButtonDown;



		}
		private void Rectangle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			

			this.dragobject = sender as UIElement;
			this.offset = e.GetPosition(Rectangle);
			this.offset.Y -= Canvas.GetTop(this.dragobject);
			this.offset.X -= Canvas.GetLeft(this.dragobject);
			Rectangle.CaptureMouse();
			
			
		}

		// Method for when rectangle is clicked
		private void Rectangle_MouseMove(object sender, MouseEventArgs e)
		{
			if (this.dragobject == null)
			{
				return;
			}
			var position = e.GetPosition(sender as IInputElement);
			Canvas.SetTop(this.dragobject, position.Y - this.offset.Y);
			Canvas.SetLeft(this.dragobject, position.X - this.offset.X);
		}
		private void Rectangle_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.dragobject = null;
			this.Rectangle.ReleaseMouseCapture();
		}
	}
}
