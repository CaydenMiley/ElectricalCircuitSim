﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ElectricalCircuitSimulator1
{
    public class Resistor
    {
        private bool isDragging;
        private Point startPoint;
        UIElement dragobject = null;
        Point offset;
        // Initialises the rectangle
        public Rectangle Rectangle { get; }


        public Resistor(double width, double height, Brush fill)
        {
            Rectangle = new Rectangle
            {
                Width = width,
                Height = height,
                Fill = fill

            };

            // Sets position of rectangle on canvas

            Canvas.SetLeft(Rectangle, 10);
            Canvas.SetTop(Rectangle, 10);



        }
    }
}
