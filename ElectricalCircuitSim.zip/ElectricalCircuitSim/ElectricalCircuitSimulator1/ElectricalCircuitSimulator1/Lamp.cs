﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ElectricalCircuitSimulator1
{
    class Lamp
    {
        public Ellipse lamp { get; }
        public Lamp(double width, double height, Brush fill)
        {
            lamp = new Ellipse
            {
                Width = width,
                Height = height,
                Fill = fill

            };

            // Sets position of rectangle on canvas

            Canvas.SetLeft(lamp, 10);
            Canvas.SetTop(lamp, 10);
        }

    }
}
